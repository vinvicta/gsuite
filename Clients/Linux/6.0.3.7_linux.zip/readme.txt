By default connects to listserver.graal.in:14911

Edit/make license.graal to set your listserver:
  your-server-host.com
  port-number


* Ctrl+Shift+L: Server selector on start (when multiple servers are configured in license.graal)

Add multiple host/port pairs to license.graal:
  host1
  port1
  host2
  port2
