bigshield.gif is a bigger shield.
You can test it with by adding 
'if (playerenters) setshield bigshield.gif,1;'
to the script of an npc