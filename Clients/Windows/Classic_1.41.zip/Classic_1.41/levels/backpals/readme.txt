picsgold.gif is a color palette with golden colors.
Do 'if (playerenters) setbackpal picsgold.gif;' in the script of an npc
to make your levels look golden.