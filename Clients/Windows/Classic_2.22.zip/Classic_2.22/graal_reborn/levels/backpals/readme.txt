picsgold.png is a color palette with golden colors.
Do 'if (playerenters) setbackpal picsgold.png;' in the script of an npc
to make your levels look golden.