bigshield.png is a bigger shield.
You can test it with by adding 
'if (playerenters) setshield bigshield.png,1;'
to the script of an npc